# Protocol Drafts

These files contain specifications that have been selected from the proposals submitted to the beckn protocol specifications. The are currently under review by different working groups in the various categories supported beckn protocol governance.

After sufficient deliberation, these drafts may be published as a Protocol Standard.